
import express from 'express';
import { quantumIntegrationService } from '../services/quantumIntegrationService';

const router = express.Router();

// Initialize quantum service
router.post('/initialize', async (req, res) => {
  try {
    const initialized = await quantumIntegrationService.initialize();
    res.json({ 
      success: initialized,
      message: initialized ? 'Quantum service initialized' : 'Failed to initialize quantum service'
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// Run QAOA algorithm
router.post('/qaoa', async (req, res) => {
  try {
    const { graphEdges, numNodes, reps = 1 } = req.body;
    
    if (!graphEdges || !numNodes) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required parameters: graphEdges, numNodes' 
      });
    }

    const result = await quantumIntegrationService.runQAOA(graphEdges, numNodes, reps);
    res.json({ success: true, ...result });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// Run Shor's algorithm
router.post('/shor', async (req, res) => {
  try {
    const { number } = req.body;
    
    if (!number) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required parameter: number' 
      });
    }

    const result = await quantumIntegrationService.runShor(number);
    res.json({ success: true, ...result });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// Run Grover's algorithm
router.post('/grover', async (req, res) => {
  try {
    const { numQubits, markedStates } = req.body;
    
    if (!numQubits || !markedStates) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required parameters: numQubits, markedStates' 
      });
    }

    const result = await quantumIntegrationService.runGrover(numQubits, markedStates);
    res.json({ success: true, ...result });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// Get job status
router.get('/jobs/:jobId', (req, res) => {
  try {
    const { jobId } = req.params;
    const job = quantumIntegrationService.getJob(jobId);
    
    if (!job) {
      return res.status(404).json({ 
        success: false, 
        error: 'Job not found' 
      });
    }

    res.json({ success: true, job });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// Get all jobs
router.get('/jobs', (req, res) => {
  try {
    const jobs = quantumIntegrationService.getAllJobs();
    res.json({ success: true, jobs });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

// Migrate attached quantum assets
router.post('/migrate-assets', async (req, res) => {
  try {
    await quantumIntegrationService.migrateAttachedAssets();
    res.json({ 
      success: true, 
      message: 'Quantum assets migrated successfully' 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
});

export default router;
