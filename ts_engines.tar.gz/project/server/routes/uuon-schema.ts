
import { Router, Request, Response } from 'express';
import { uuonSchemaIntegration } from '../uuon-schema-integration';

const router = Router();

// Check UUON schema status
router.get('/status', async (req: Request, res: Response) => {
  try {
    const schemaStatus = await uuonSchemaIntegration.verifyUUONSchema();
    const stats = await uuonSchemaIntegration.getUUONStats();
    
    res.json({
      success: true,
      schema: {
        compatible: schemaStatus.compatible,
        existingTables: schemaStatus.existingTables,
        missingTables: schemaStatus.missingTables,
        tableCount: schemaStatus.existingTables.length
      },
      economy: {
        totalTokens: stats.totalTokens,
        mintedTokens: stats.mintedTokens,
        totalValue: stats.totalValue,
        energyActive: !!stats.energyStats
      },
      recommendation: schemaStatus.compatible 
        ? 'UUON Token Economy fully operational'
        : `Deploy missing tables: ${schemaStatus.missingTables.join(', ')}`
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to check UUON schema status'
    });
  }
});

// Initialize UUON schema
router.post('/initialize', async (req: Request, res: Response) => {
  try {
    const migration = await uuonSchemaIntegration.migrateToUUONSchema();
    
    res.json({
      success: migration.success,
      migrated: migration.migrated,
      message: migration.success 
        ? 'UUON Token Economy initialized successfully'
        : 'UUON schema initialization failed - check database permissions'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'UUON initialization failed'
    });
  }
});

// Sync data from shape_tokens to UUON tables
router.post('/sync-from-tokens', async (req: Request, res: Response) => {
  try {
    const result = await uuonSchemaIntegration.syncFromShapeTokens();
    
    res.json({
      success: result.success,
      synced: result.synced,
      errors: result.errors.slice(0, 10),
      message: result.success 
        ? `Successfully synced ${result.synced} shapes to UUON tables`
        : 'Sync failed - check errors'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'UUON sync failed'
    });
  }
});

// Get complete UUON economy overview
router.get('/economy-overview', async (req: Request, res: Response) => {
  try {
    const stats = await uuonSchemaIntegration.getUUONStats();
    const schemaStatus = await uuonSchemaIntegration.verifyUUONSchema();
    
    res.json({
      success: true,
      uuonEconomy: {
        active: schemaStatus.compatible,
        tokens: {
          total: stats.totalTokens,
          minted: stats.mintedTokens,
          pending: stats.totalTokens - stats.mintedTokens,
          totalValue: stats.totalValue
        },
        energy: stats.energyStats,
        schema: {
          version: '1.0.0',
          tables: schemaStatus.existingTables.length,
          complete: schemaStatus.compatible
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to get UUON economy overview'
    });
  }
});

export default router;
