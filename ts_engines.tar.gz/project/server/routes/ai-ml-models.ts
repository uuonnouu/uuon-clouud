
import { Router } from 'express';
import { neon } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import { eq, like, desc, asc } from 'drizzle-orm';
import { ai_ml_models, model_performance_logs } from '../../shared/ai-ml-models-schema';

const router = Router();
const connectionString = process.env.DATABASE_URL!;
const sql = neon(connectionString);
const db = drizzle(sql);

// Get all AI/ML models with pagination and filtering
router.get('/models', async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 50, 
      category, 
      search,
      sort = 'name',
      order = 'asc',
      premium_only = 'false'
    } = req.query;

    const offset = (Number(page) - 1) * Number(limit);
    let query = db.select().from(ai_ml_models);

    // Apply filters
    if (category) {
      query = query.where(eq(ai_ml_models.category, category as string));
    }

    if (search) {
      query = query.where(like(ai_ml_models.model_name, `%${search}%`));
    }

    if (premium_only === 'true') {
      query = query.where(eq(ai_ml_models.is_premium, true));
    }

    // Apply sorting
    const sortField = sort === 'downloads' ? ai_ml_models.download_count :
                     sort === 'created' ? ai_ml_models.created_at :
                     ai_ml_models.model_name;

    query = order === 'desc' ? 
            query.orderBy(desc(sortField)) : 
            query.orderBy(asc(sortField));

    // Apply pagination
    const models = await query.limit(Number(limit)).offset(offset);

    // Get total count for pagination
    const totalQuery = db.select({ count: sql`COUNT(*)` }).from(ai_ml_models);
    const [{ count }] = await totalQuery;

    res.json({
      success: true,
      models: models.map(model => ({
        ...model,
        model_url: `${req.protocol}://${req.get('host')}${model.url_slug}`,
        api_endpoint: `${req.protocol}://${req.get('host')}/api/ai-ml/model/${model.id}`,
        download_url: `${req.protocol}://${req.get('host')}/api/ai-ml/download/${model.id}`
      })),
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: Number(count),
        pages: Math.ceil(Number(count) / Number(limit))
      }
    });
  } catch (error) {
    console.error('Failed to fetch AI/ML models:', error);
    res.status(500).json({ error: 'Failed to fetch models' });
  }
});

// Get specific AI/ML model by ID
router.get('/model/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const model = await db.select().from(ai_ml_models).where(eq(ai_ml_models.id, Number(id))).limit(1);

    if (model.length === 0) {
      return res.status(404).json({ error: 'Model not found' });
    }

    // Get performance metrics
    const performance = await db.select()
      .from(model_performance_logs)
      .where(eq(model_performance_logs.model_id, Number(id)))
      .orderBy(desc(model_performance_logs.timestamp))
      .limit(5);

    res.json({
      success: true,
      model: {
        ...model[0],
        model_url: `${req.protocol}://${req.get('host')}${model[0].url_slug}`,
        api_endpoint: `${req.protocol}://${req.get('host')}/api/ai-ml/model/${id}`,
        download_url: `${req.protocol}://${req.get('host')}/api/ai-ml/download/${id}`,
        visualization_url: `${req.protocol}://${req.get('host')}/?shape=${model[0].shape_type}`,
        recent_performance: performance
      }
    });
  } catch (error) {
    console.error('Failed to fetch model:', error);
    res.status(500).json({ error: 'Failed to fetch model' });
  }
});

// Get models by category
router.get('/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const { limit = 20 } = req.query;

    const models = await db.select()
      .from(ai_ml_models)
      .where(eq(ai_ml_models.category, category))
      .orderBy(desc(ai_ml_models.download_count))
      .limit(Number(limit));

    res.json({
      success: true,
      category,
      models: models.map(model => ({
        ...model,
        model_url: `${req.protocol}://${req.get('host')}${model.url_slug}`,
        api_endpoint: `${req.protocol}://${req.get('host')}/api/ai-ml/model/${model.id}`,
        visualization_url: `${req.protocol}://${req.get('host')}/?shape=${model.shape_type}`
      })),
      total: models.length
    });
  } catch (error) {
    console.error('Failed to fetch category models:', error);
    res.status(500).json({ error: 'Failed to fetch category models' });
  }
});

// Download/Export AI/ML model
router.get('/download/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { format = 'json' } = req.query;

    const model = await db.select().from(ai_ml_models).where(eq(ai_ml_models.id, Number(id))).limit(1);

    if (model.length === 0) {
      return res.status(404).json({ error: 'Model not found' });
    }

    // Increment download count
    await db.update(ai_ml_models)
      .set({ download_count: model[0].download_count + 1 })
      .where(eq(ai_ml_models.id, Number(id)));

    const modelData = model[0];

    if (format === 'json') {
      res.setHeader('Content-Disposition', `attachment; filename="${modelData.model_name}.json"`);
      res.json({
        model_info: modelData,
        mathematical_foundation: {
          equation: modelData.mathematical_equation,
          shape_type: modelData.shape_type,
          category: modelData.category
        },
        ai_architecture: modelData.ml_architecture,
        capabilities: modelData.ai_capabilities,
        usage_instructions: {
          visualization_url: `${req.protocol}://${req.get('host')}/?shape=${modelData.shape_type}`,
          api_endpoint: `${req.protocol}://${req.get('host')}/api/ai-ml/model/${id}`,
          integration_guide: "Use this model with the Δmension Mathematical Universe platform"
        },
        export_timestamp: new Date().toISOString(),
        platform: "Δmension Mathematical Universe - AI/ML Models"
      });
    } else {
      res.status(400).json({ error: 'Unsupported format. Use format=json' });
    }
  } catch (error) {
    console.error('Failed to download model:', error);
    res.status(500).json({ error: 'Failed to download model' });
  }
});

// Search AI/ML models
router.get('/search', async (req, res) => {
  try {
    const { q, category, limit = 20 } = req.query;

    if (!q) {
      return res.status(400).json({ error: 'Search query required' });
    }

    let query = db.select().from(ai_ml_models)
      .where(like(ai_ml_models.model_name, `%${q}%`));

    if (category) {
      query = query.where(eq(ai_ml_models.category, category as string));
    }

    const models = await query
      .orderBy(desc(ai_ml_models.download_count))
      .limit(Number(limit));

    res.json({
      success: true,
      query: q,
      category: category || 'all',
      models: models.map(model => ({
        ...model,
        model_url: `${req.protocol}://${req.get('host')}${model.url_slug}`,
        api_endpoint: `${req.protocol}://${req.get('host')}/api/ai-ml/model/${model.id}`,
        visualization_url: `${req.protocol}://${req.get('host')}/?shape=${model.shape_type}`
      })),
      total: models.length
    });
  } catch (error) {
    console.error('Search failed:', error);
    res.status(500).json({ error: 'Search failed' });
  }
});

// Get AI/ML statistics
router.get('/stats', async (req, res) => {
  try {
    const stats = await db.select({
      total_models: sql`COUNT(*)`,
      total_downloads: sql`SUM(download_count)`,
      premium_models: sql`COUNT(*) FILTER (WHERE is_premium = true)`,
      categories: sql`COUNT(DISTINCT category)`
    }).from(ai_ml_models);

    const categoryBreakdown = await db.select({
      category: ai_ml_models.category,
      count: sql`COUNT(*)`
    }).from(ai_ml_models)
      .groupBy(ai_ml_models.category)
      .orderBy(desc(sql`COUNT(*)`));

    res.json({
      success: true,
      statistics: {
        ...stats[0],
        category_breakdown: categoryBreakdown,
        last_updated: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('Failed to fetch stats:', error);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

export { router as aimlModelsRouter };
