# Documentation Templates

This directory contains standardized templates for Δmension Mathematical Universe documentation.

## Structure
- `internal/` - Technical, business, and security documentation
- `public/` - User-facing guides and API documentation  
- `modules/` - Individual module documentation
- `systems/` - System architecture documentation
- `components/` - Component-level documentation
- `utilities/` - Utility function documentation

## Usage
Copy the appropriate template and customize for your needs.
