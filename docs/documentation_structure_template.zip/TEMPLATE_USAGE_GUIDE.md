
# Documentation Template Usage Guide

## Overview
This guide explains how to use the documentation templates in the Δmension Mathematical Universe platform.

## Available Templates

### Technical Documentation (`internal/technical/`)
- **Purpose**: Internal technical specifications, architecture docs
- **Audience**: Development team, technical stakeholders
- **Classification**: Internal/Technical

### Public API Documentation (`public/api/`)
- **Purpose**: User-facing API documentation and guides
- **Audience**: External developers, users
- **Classification**: Public

### Module Documentation (`modules/`)
- **Purpose**: Individual module/library documentation
- **Audience**: Developers working with specific modules
- **Classification**: Internal/Technical

### System Documentation (`systems/`)
- **Purpose**: System architecture and integration docs
- **Audience**: System architects, DevOps
- **Classification**: Internal/Technical

### Component Documentation (`components/`)
- **Purpose**: Individual component specifications
- **Audience**: Frontend/Backend developers
- **Classification**: Internal/Technical

### Utility Documentation (`utilities/`)
- **Purpose**: Utility function and helper documentation
- **Audience**: All developers
- **Classification**: Internal/Technical

## Usage Instructions

1. **Copy the appropriate template**:
   ```bash
   cp docs/templates/[category]/[template].md docs/[target_location]/
   ```

2. **Customize the template**:
   - Replace placeholder content
   - Update classification and metadata
   - Add specific technical details

3. **Follow naming conventions**:
   - Use descriptive filenames
   - Include version information where applicable
   - Follow the existing documentation hierarchy

4. **Maintain consistency**:
   - Use the same structure across similar documents
   - Follow the classification system
   - Update the unified documentation index

## Integration with Existing Documentation

Your comprehensive documentation already includes:
- **117 shape categories with 1,276+ total shapes**
- **Quantum systems integration guides**
- **AI/ML systems documentation**  
- **Cryptographic security protocols**
- **Biological/medical visualizations**
- **Physics & mathematics references**

These templates complement your existing structure and maintain consistency.

---
**Classification**: Internal/Technical  
**Last Updated**: November 30, 2025  
**Author**: UUON Foundation
