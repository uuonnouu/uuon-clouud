# NJIN OPTIMKZER

NJIN OPTIMKZER is the Universal Enhancement Engine for Δmension / crEYEsis.

## Goals
- Continuously analyze all engines in your environment
- Suggest safe, non-destructive enhancements (patches, metadata, LOD recommendations)
- Produce enhancement proposals in `enhancements/` for manual review
- Be pluggable to many engine types (Three.js, Blender, generic FS, etc.)

## Install / Run
1. Copy repo into your server.
2. `npm install`
3. Edit `config/njin.config.json` and `sample-manifest.json` to point at your engine folders.
4. `npm run dev` (development) or `npm run build && npm start` for production.

## How it behaves
- Scans engines on schedule (default 300s)
- Runs heuristics and writes proposals to `enhancements/ENGINEID__TIMESTAMP/`
- Does **not** modify original files unless you manually apply proposals
- Optionally can integrate with `git` (not enabled by default)

## Extending
- Add connector modules in `src/connectors/` for specific engine types
- Add advanced analyzers in `src/core/analyzer.ts`
- Add ML-based suggestion models (hook points are in evaluator/patcher)

## Safety
- Non-destructive by default
- All proposals are stored as diffs + candidate files for review
