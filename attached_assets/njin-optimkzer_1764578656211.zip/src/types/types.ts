export type EngineDescriptor = {
  id: string;
  type: string; // 'three' | 'blender' | 'generic' | etc
  path: string; // local filesystem path
  entry?: string; // main file to inspect
  metadata?: Record<string, any>;
};

export type AnalysisResult = {
  engineId: string;
  timestamp: string;
  metrics: Record<string, any>;
  issues: Array<{ code: string; severity: "info" | "warning" | "critical"; message: string; data?: any }>;
  suggestions?: Array<{ id: string; title: string; details: string; patchCandidatePath?: string }>;
};
