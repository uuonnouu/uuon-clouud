import path from "path";
import { EngineDescriptor } from "../types/types";

export async function canUseBlender(): Promise<boolean> {
  // default false; user must enable and point to blender binary if available
  return false;
}

export async function requestBlenderOptimize(engine: EngineDescriptor, modelPath: string, outPath: string, options?: any) {
  throw new Error("Blender not configured. Configure Blender integration to use headless optimization.");
}
