import fs from "fs";
import path from "path";
import { EngineDescriptor } from "../types/types";

/**
 * Generic filesystem connector: exposes basic operations to read engine files and metadata.
 * Every connector should implement a subset of these functions so core can call them generically.
 */

export async function listEngineFiles(engine: EngineDescriptor): Promise<string[]> {
  const root = engine.path;
  if (!fs.existsSync(root)) return [];
  const files: string[] = [];
  function walk(dir: string) {
    for (const name of fs.readdirSync(dir)) {
      const p = path.join(dir, name);
      const stat = fs.statSync(p);
      if (stat.isDirectory()) walk(p);
      else files.push(path.relative(root, p));
    }
  }
  walk(root);
  return files;
}

export function readEngineFile(engine: EngineDescriptor, relativeFile: string): string | null {
  const p = path.join(engine.path, relativeFile);
  try {
    return fs.readFileSync(p, "utf8");
  } catch {
    return null;
  }
}
