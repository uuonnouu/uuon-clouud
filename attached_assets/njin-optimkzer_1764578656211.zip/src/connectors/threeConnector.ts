import { EngineDescriptor } from "../types/types";
import path from "path";
import fs from "fs";
import { readEngineFile } from "./../core/registry";

export async function inspectThreeEngine(engine: EngineDescriptor) {
  const files = await (await import("./genericFSConnector")).listEngineFiles(engine);
  const hints: string[] = [];
  const gltfFiles = files.filter(f => f.endsWith(".glb") || f.endsWith(".gltf"));
  if (gltfFiles.length > 0) {
    hints.push(`Found ${gltfFiles.length} glTF files (possible high-detail meshes).`);
  }
  // check for GLTFLoader usage
  const code = readEngineFile(engine, engine.entry || "index.js");
  if (code && /GLTFLoader/.test(code)) {
    hints.push("Uses GLTFLoader (Three.js) - recommend DRACO compression + LOD pipeline.");
  }
  return {
    engineId: engine.id,
    hints,
    gltfFiles
  };
}
