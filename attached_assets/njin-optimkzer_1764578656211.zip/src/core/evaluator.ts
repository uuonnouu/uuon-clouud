import path from "path";
import { loadManifest, safeReadFile } from "./registry";
import { analyzeEngine } from "./analyzer";
import { writeEnhancementProposal } from "./patcher";
import { logger } from "../utils/logger";
import fs from "fs";
import { EngineDescriptor } from "../types/types";

const CONFIG_PATH = path.resolve(__dirname, "../../config/njin.config.json");
const MANIFEST_PATH = path.resolve(__dirname, "../../sample-manifest.json");

export async function runEvaluationOnce() {
  const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
  const manifest = loadManifest(MANIFEST_PATH);
  for (const engine of manifest) {
    logger.info("Analyzing engine:", engine.id);
    try {
      const analysis = await analyzeEngine(engine);
      // decide if a proposal is needed
      const needsProposal = (analysis.issues && analysis.issues.length > 0) && (analysis.metrics.score < 95);
      if (needsProposal) {
        // create a simple example patch candidate: augment metadata.json with units if missing
        const metaPath = path.join(engine.path, "metadata.json");
        const metaExists = fs.existsSync(metaPath);
        if (!metaExists) {
          const candidate = {
            units: "meters",
            scale: 1.0,
            createdBy: "njin-optimkzer",
            createdAt: new Date().toISOString()
          };
          const oldText = "";
          const newText = JSON.stringify(candidate, null, 2);
          writeEnhancementProposal(cfg.enhancementsPath, {
            engineId: engine.id,
            timestamp: new Date().toISOString(),
            metrics: analysis.metrics,
            issues: analysis.issues
          } as any, { filename: path.relative(process.cwd(), metaPath), oldText, newText });
        } else {
          // write analysis only
          writeEnhancementProposal(cfg.enhancementsPath, {
            engineId: engine.id,
            timestamp: new Date().toISOString(),
            metrics: analysis.metrics,
            issues: analysis.issues
          } as any);
        }
      } else {
        logger.info(`Engine ${engine.id} scored ${analysis.metrics.score} — no proposal generated.`);
      }
    } catch (e) {
      logger.error("Failed to analyze", engine.id, e);
    }
  }
}
