import { runEvaluationOnce } from "./evaluator";
import { logger } from "../utils/logger";
import fs from "fs";
import path from "path";

const CONFIG_PATH = path.resolve(__dirname, "../../config/njin.config.json");

export function startScheduler() {
  const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
  const interval = Math.max(60, cfg.scanIntervalSeconds || 300) * 1000;
  logger.info(`NJIN Scheduler starting. Running every ${interval / 1000}s`);
  // initial run
  runEvaluationOnce().catch(err => logger.error("Initial run failed", err));
  // periodic runs
  setInterval(() => {
    runEvaluationOnce().catch(err => logger.error("Scheduled run failed", err));
  }, interval);
}
