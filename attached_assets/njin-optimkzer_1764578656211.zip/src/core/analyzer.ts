import { EngineDescriptor } from "../types/types";
import { readEngineFile } from "./registry";
import { logger } from "../utils/logger";
import { safeReadFile } from "./registry";
import fs from "fs";
import path from "path";

export async function analyzeEngine(engine: EngineDescriptor) {
  const timestamp = new Date().toISOString();
  const issues: Array<{ code: string; severity: "info"|"warning"|"critical"; message: string; data?: any }> = [];
  const metrics: Record<string, any> = {};

  // Heuristic 1: file size & vertex proxies (look for large .glb)
  const root = engine.path;
  if (fs.existsSync(root)) {
    const files = fs.readdirSync(root);
    const glbFiles = files.filter(f => f.endsWith(".glb") || f.endsWith(".gltf"));
    metrics.gltfCount = glbFiles.length;
    if (glbFiles.length > 0) {
      let totalBytes = 0;
      for (const f of glbFiles) {
        const stat = fs.statSync(path.join(root, f));
        totalBytes += stat.size;
      }
      metrics.gltfTotalBytes = totalBytes;
      if (totalBytes > 50 * 1024 * 1024) {
        issues.push({
          code: "LARGE_GLTF",
          severity: "warning",
          message: `GLTF assets are large (${Math.round(totalBytes/1024/1024)} MB). Consider LODs and DRACO compression.`,
          data: { totalBytes }
        });
      }
    }
  } else {
    issues.push({ code: "MISSING_PATH", severity: "critical", message: `Engine path not found: ${engine.path}` });
    return {
      engineId: engine.id,
      timestamp,
      metrics,
      issues
    };
  }

  // Heuristic 2: check for GLTFLoader usage (Three.js engines)
  const entry = engine.entry || "index.js";
  const code = safeReadFile(path.join(engine.path, entry));
  if (code && /GLTFLoader/.test(code)) {
    metrics.usesGLTFLoader = true;
    // recommend DRACO if not present
    if (!/DRACOLoader/.test(code) && !/draco/.test(JSON.stringify(fs.readdirSync(engine.path)))) {
      issues.push({
        code: "DRACO_MISSING",
        severity: "info",
        message: "GLTF assets loaded but DRACO compression not used. Consider compressing glTF with DRACO/Basis for faster load times."
      });
    }
  }

  // Heuristic 3: search for heavy sync loops / suspicious patterns
  if (code && /while\s*\(true\)|for\s*\(;\;\)|setInterval\s*\(.{0,30}\)/.test(code)) {
    issues.push({
      code: "POTENTIAL_BLOCKING_LOOP",
      severity: "warning",
      message: "Found potential blocking loop pattern. Evaluate async yielding or worker offload."
    });
  }

  // Heuristic 4: detect missing unit/scale metadata (for anatomy engines)
  if (/anatomy|heart|cortex|lung/i.test(engine.id + " " + JSON.stringify(engine.metadata || {}))) {
    // check for a metadata file
    const metaPath = path.join(engine.path, "metadata.json");
    if (!fs.existsSync(metaPath)) {
      issues.push({
        code: "NO_SCALE_METADATA",
        severity: "info",
        message: "Anatomy engine with no metadata.json found. Recommend adding 'units' and 'scale' to ensure consistent deformation amplitudes."
      });
    } else {
      try {
        const meta = JSON.parse(fs.readFileSync(metaPath, "utf8"));
        metrics.units = meta.units || null;
      } catch {}
    }
  }

  // Heuristic 5: quick code size and dependency check
  try {
    const packagePath = path.join(engine.path, "package.json");
    if (fs.existsSync(packagePath)) {
      const pkg = JSON.parse(fs.readFileSync(packagePath, "utf8"));
      metrics.depCount = Object.keys(pkg.dependencies || {}).length;
      if (pkg.dependencies && pkg.dependencies["three"]) {
        metrics.usesThree = true;
      }
    }
  } catch (e) {
    logger.warn("Failed to parse package.json for", engine.id);
  }

  // add a simple 'score' metric (0..100) based on rudimentary heuristics
  let score = 80;
  if (metrics.gltfTotalBytes && metrics.gltfTotalBytes > 50 * 1024 * 1024) score -= 10;
  if (metrics.depCount && metrics.depCount > 30) score -= 5;
  const final = {
    engineId: engine.id,
    timestamp,
    metrics: { ...metrics, score },
    issues
  };
  return final;
}
