import fs from "fs";
import path from "path";
import { AnalysisResult } from "../types/types";
import { createTextPatch } from "../utils/diff";
import { logger } from "../utils/logger";

export function ensureEnhancementsFolder(rootPath: string) {
  if (!fs.existsSync(rootPath)) fs.mkdirSync(rootPath, { recursive: true });
}

/**
 * writeEnhancementProposal: stores a JSON record and optional patch text
 */
export function writeEnhancementProposal(enhancementsRoot: string, analysis: AnalysisResult, patch?: { filename: string; oldText: string; newText: string }) {
  ensureEnhancementsFolder(enhancementsRoot);
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const id = `${analysis.engineId}__${timestamp}`;
  const folder = path.join(enhancementsRoot, id);
  fs.mkdirSync(folder);
  const meta = {
    id,
    engineId: analysis.engineId,
    createdAt: new Date().toISOString(),
    analysis
  };
  fs.writeFileSync(path.join(folder, "proposal.json"), JSON.stringify(meta, null, 2));
  if (patch) {
    const patchText = createTextPatch(patch.filename, patch.oldText, patch.newText);
    fs.writeFileSync(path.join(folder, "patch.diff"), patchText);
    // also write the new file candidate for ease of review
    fs.writeFileSync(path.join(folder, "candidate_" + path.basename(patch.filename)), patch.newText);
  }
  logger.info("Wrote enhancement proposal:", id);
  return { id, folder };
}
