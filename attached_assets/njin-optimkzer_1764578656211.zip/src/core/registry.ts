import fs from "fs";
import path from "path";
import { EngineDescriptor } from "../types/types";
import { logger } from "../utils/logger";

/**
 * Simple registry loader. Loads a manifest JSON (like sample-manifest.json)
 * and returns engine descriptors. You can extend to read from a DB.
 */
export function loadManifest(manifestPath: string): EngineDescriptor[] {
  try {
    const raw = fs.readFileSync(manifestPath, "utf8");
    const json = JSON.parse(raw);
    const engines = json.engines as EngineDescriptor[];
    logger.info(`Loaded ${engines.length} engines from manifest`);
    return engines;
  } catch (e) {
    logger.error("Failed to load manifest", e);
    return [];
  }
}

/**
 * Helper to read a file; returns null if not present
 */
export function safeReadFile(filePath: string): string | null {
  try {
    return fs.readFileSync(filePath, "utf8");
  } catch {
    return null;
  }
}
