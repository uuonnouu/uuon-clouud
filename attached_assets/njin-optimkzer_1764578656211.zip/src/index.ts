import { startScheduler } from "./core/scheduler";
import { logger } from "./utils/logger";
import path from "path";
import fs from "fs";

// ensure enhancements folder exists
const cfgPath = path.resolve(__dirname, "../config/njin.config.json");
const cfg = JSON.parse(fs.readFileSync(cfgPath, "utf8"));
const enhPath = path.resolve(process.cwd(), cfg.enhancementsPath || "./enhancements");
if (!fs.existsSync(enhPath)) fs.mkdirSync(enhPath, { recursive: true });

logger.info("Starting NJIN OPTIMKZER...");
startScheduler();

// graceful shutdown
process.on("SIGINT", () => {
  logger.info("NJIN received SIGINT — shutting down.");
  process.exit(0);
});
