export const logger = {
  info: (...args: any[]) => console.log("[NJIN.INFO]", ...args),
  warn: (...args: any[]) => console.warn("[NJIN.WARN]", ...args),
  error: (...args: any[]) => console.error("[NJIN.ERROR]", ...args),
  debug: (...args: any[]) => {
    if (process.env.NJIN_DEBUG === "1") console.debug("[NJIN.DEBUG]", ...args);
  }
};
