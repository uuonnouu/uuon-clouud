import { createPatch } from "diff";

/**
 * createTextPatch: returns a unified diff string between oldText and newText
 */
export function createTextPatch(filename: string, oldText: string, newText: string): string {
  const patch = createPatch(filename, oldText, newText, "original", "proposal");
  return patch;
}
